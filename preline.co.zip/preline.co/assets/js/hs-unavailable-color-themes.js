window.HS_UNAVAILABLE_COLOR_THEMES = {
  // "crm": {
  //   "theme": "crm",
  //   "excludes": {
  //     "*": ["agency", "payment"],
  //     "index": ["cms"]
  //   }
  // },
  // "workspace": {
  //   "theme": "workspace",
  //   "excludes": ["shop-marketplace", "files", "smart-home"]
  // }
};